
import UIKit        //匯入基本框架以確保功能可以運作

var greeting = "Hello, playground"  //String型別
greeting = "Welcome"  // &我的測試&-->(move") error:Unterminated string literal

//不需要main()函式。也不需要在每個語句的末尾編寫分號。
print("Hello, world!") //// &我的測試&-->(move") error:Unterminated string literal
// Prints "Hello, world!"

//==============單一值(Simple Values/Single Values)==============
//-------------------以"型別推測"機制建立變數或常數--------------------
//使用let建立常數（constant）和var建立變數（variable）
var myVariable = 42     //=為assign(設值) PS.根據設定值推測為Int型別(整數型別)
//&我的測試& var myVariable! = 42 --> error:Consecutive statements on a line must be separated by ';'
print(myVariable)

myVariable = 50
print(myVariable)

//myVariable = 49.99      //error:Cannot assign value of type 'Double' to type 'Int'

let myConstant = 42       //Int型別
print(myConstant)
//myConstant = 50 //error:Cannot assign to value: 'myConstant' is a 'let' constant

//-------------------以"明確型別"建立變數或常數--------------------
let implicitInteger = 70    //推測為Int型別
let implicitDouble = 70.0   //推測為Double型別(浮點數型別)
let explicitDouble:Double = 70     //以冒號明確宣告型別
//注意：當等號兩邊空白不一致時~Error'=' must have consistent whitespace on both sides
//當宣告常數或變數，沒有初始值時，必須明確型別
let explicitDouble1: Double
explicitDouble1 = 49.8888888888888888888        //當常數第一次設值之後就不可事後變動
//explicitDouble1 = 3.99      //error:Immutable value 'explicitDouble1' may only be initialized once
print(explicitDouble1)

//注意："型別"皆為英文"大寫"開頭的駝峰式命名法，其餘的命名"建議"為小寫開頭的駝峰式命名法

//【練習1】建立一個常數，明確型別為Float，且初始值為4。
let explicitFloat:Float = 3.88888888888
//注意：Float的小數位數比Double少，較不佔記憶體配置空間，Float不適用於型別推測機制，型別推測機制只會推測為Double，如果存放時超出可容納的小數位數，會直接截斷多餘的小數
print(explicitFloat)

//觀察整數型別的最大最小值
Int.max
Int.min
myVariable = 9223372036854775807
//myVariable = 9223372036854775808    //溢位overflow，因為超出整數的最大值
//myVariable = -9223372036854775809     //溢位overflow，因為超出整數的最小值

//Swift不會自動轉型
let label = "The width is "     //String型別
let width = 94                  //Int型別
let widthLabel = label + String(width)  //= "The width is " + "94"
                         //此轉型非真正的轉型，而是另外製作一個實體（instance）

//【練習2】將最後一行String的轉換語法刪除。你得到什麼錯誤？
//error: Binary operator '+' cannot be applied to operands of type 'String' and 'Int'
//operator:運算子（運算符號）
//operand:運算元(素)

print(widthLabel)

let covertedFloat = String(explicitFloat)       //String型別

let covertedDouble = Double(implicitInteger)    //Double型別

let covertedDouble1 = Int(explicitDouble)       //Int型別
print(covertedDouble1)

var labelWidth = "88"
let covertedWidthInt = Int(labelWidth)           //Int?型別
let covertedWidthDouble = Double(labelWidth)     //Double?型別
print(covertedWidthInt)

//Expression implicitly coerced from 'Int?' to 'Any'

labelWidth = "Test"
let covertedWidthInt1 = Int(labelWidth)          //Int?型別(轉換失敗時會回報空值nil/NULL)

//還有一種更便利的語法可以在字串中包含值，使用\() 《挖洞語法》
let apples = 3
let oranges = 5
let appleSummary = "I have \(apples) apples."
//挖洞之中，一樣必須相同型別才能運算
let fruitSummary = "I have \(apples + oranges) pieces of fruit."

//【練習3】使用\()在字串中包含浮點數的計算，並在問候語中包含某人的名字。
//BMI: 體重(公斤) / 身高的平方(公尺)
//"某人你好：你的BMI是"
let myHeight = 1.66
let myWeight = 62.0
let myName = "Perkin"
let message = "\(myName)你好：你的BMI是\(myWeight / (myHeight*myHeight))"

String(format: "%@你好：你的BMI是%.2f", myName,myWeight / (myHeight*myHeight))


//以三個雙引號(""")來標示字串，字串的中間即可以保留換行和單引號(")的呈現
let quotation = """
        Even though there's whitespace to the left,
        the actual lines aren't indented.
            Except for this line.
        Double quotes (") can appear without being escaped.

        I still have \(apples + oranges) pieces of fruit.
        """
print(quotation)

//=====================複合值（Compound Value）======================
//====================集合型別（Collection Type）====================
//Swift提供了三種主要的集合型別，稱為陣列（array）、集合（set）和字典（dictionary）
//陣列（array）是有序的集合(以索引值定出值的順序)，集合（set）是唯一值的無序集合，字典（dictionary）是"鍵值關聯"(key-value associations/key-value pair)
/*（陣列) index對應Values 有序集合 有索引值 從０起算
   (Set) 只有Values      無序集合 有唯一值
   (Dictionary)         無序集合 有唯一值 key對應Values
*/

//陣列
var fruits = ["strawberries","limes","tangerines",] //元素的最後一個逗號可以留下！
//印出全部陣列
print(fruits)
//讀取特定索引的元素值
fruits[0]
fruits[1]   ////置換index 1對應的元素
fruits[2]
//此行會觸發執行階段錯誤（run time error），App會crash（閃退），因為超出索引值（索引值從0起算）
//fruits[3]   //error: Execution was interrupted

//檢查陣列的元素個數
fruits.count    //陣列計算數量
//針對陣列特定索引值的元素進行修改
fruits[1] = "grapes"
fruits
//新增新的陣列的元素
fruits.append("banana")
fruits
fruits.append("blueberries")
print(fruits)
//插入新的陣列的元素
fruits.insert("西瓜", at: 1)
fruits
//刪除特定位置的陣列元素
fruits.remove(at: 2)
fruits
//陣列元素兩兩對調
fruits.swapAt(0, 3)
fruits

//字典(以[key:value]來給定一筆字典的鍵值配對)
var occupations = [
    "Malcolm": "Captain",
    "Kaylee": "Mechanic",    //元素的最後一個逗號可以留下！字典最後一個元素可以出現逗號
 ]
//以key查詢字典的value
//宣告並建立字典，此字典型別為 [String:String] | "key": "value"
if let career = occupations["Malcolm"]
{
    print("Malcolm的職業是：：\(career)")
}

occupations["Kaylee"]
//當以不存在的Key查詢字典時，會回報空值nil
occupations["Perkin"]
//以目前存在的Key針對字典的值進行"修改"
occupations["Kaylee"] = "Engineer"
occupations

//以不存在的Key設定字典的值，是對字典進行"新增"
occupations["Jayne"] = "Public Relations"
occupations
//以特定Key刪除字典的一筆鍵值配對
occupations.removeValue(forKey: "Kaylee")
occupations
//當刪除的Key不存在，回報為nil
occupations.removeValue(forKey: "Test")
//確認字典有幾筆
occupations.count

//清空陣列
fruits = []
fruits.count
//清空字典
occupations = [:]
occupations.count
//--------------產生空陣列與字典的方法--------------
//<方法一>如果您要將空陣列或字典分配給新變數，您需要指定型別。
var emptyArray: [String] = []               //原範例為let
var emptyDictionary: [String: Float] = [:]  //原範例為let
emptyArray.append("test")
emptyDictionary["AB"] = 1.33
emptyArray
emptyDictionary

//<方法二>宣告新變數且沒有明確任何型別資訊時，您需要指定型別才能產生空陣列或字典。
var emptyArray1 = [String]()
var emptyDictionary1 = [String: Float]()

//<方法三>產生空陣列與字典

var emptyArray2 = Array<String>()
var emptyDictionary2 = Dictionary<String,Float>()
//-----------------------------------------------

//===================流程控制（Control Flow）===================
/*
使用if和switch來製作條件，並使用for-in、while和repeat-while來做迴圈。
條件或迴圈變數周圍的小括號()可以省略。執行範圍的body區段周圍大括號不能省略（即使只有一行）。
注意：大括號框出的範圍稱為作用域（scope），在作用域中宣告的常數或變數只在其範圍內有效！
*/
/* 條列說明流程控制
 
  1.使用if 和 seitch 建立條件判斷式，
  2.使用for - in ,while , repeat-while來建立迴圈
  3.條件判斷式和迴圈的小括號() 可以省略
  4.實作範圍 （body) 的大括號 {} 不可省略
 
*/

//團體中個人的分數
let individualScores = [75, 43, 103, 87, 12]        //[Int]
//團體的加權計分
var teamScore = 0                                   //Int
/*  error:C-style for statement has been removed in Swift 3
for(var i=0;i<individualScores.count;i=i+1)
{
    individualScores[i]
}
*/
//以for-in迴圈列出陣列
//  score為常數,需變動加var 在for後 ,in之後必為陣列
for score in individualScores   //注意:score為常數
{
    //if條件式必須是Boolean判斷式（true/false）
    if score > 50
    {
        teamScore += 3
        //teamScore = teamScore + 3
    }
    else
    {
        teamScore += 1
        // 完整語法為 teamScore = teamScore + 1
    }
}
print(teamScore)

//<補充>for-in迴圈正轉，每次加1（不含上限）
for i in 0..<individualScores.count //[0,1,2,3,4]
{
    print(individualScores[i])
}

//<補充>for-in迴圈正轉，每次加1（包含上限）
for i in 0...individualScores.count-1 //[0,1,2,3,4]
{
    print(individualScores[i])
}
//Cannot find operator '..' in scope; did you mean '...'?
//<補充>for-in迴圈反轉，每次減1（不含上限）
for i in (0..<individualScores.count).reversed() //[4,3,2,1,0]
{
    print(individualScores[i])
}

//<補充>for-in迴圈反轉，每次加1（包含上限）
for i in (0...individualScores.count-1).reversed() //[4,3,2,1,0]
{
    print(individualScores[i])
}

//<補充>for-in迴圈正轉，每次加2（不含上限）
for i in stride(from: 0, to: individualScores.count, by: 2) //[0,2,4]
{
    print(individualScores[i])
}

//<補充>for-in迴圈反轉，每次減2（包含上限）
for i in stride(from: 0, through: individualScores.count-1, by: 2) //[4,2,0]
{
    print(individualScores[i])
}

//<補充>for-in迴圈反轉，每次減2（不含上限）
for i in stride(from: individualScores.count-1, to: -1, by: -2) //[4,2,0]
{
    print(individualScores[i])
}

//<補充>for-in迴圈正轉，每次加2（包含上限）
for i in stride(from: individualScores.count-1, through: 0, by: -2) //[4,2,0]
{
    print(individualScores[i])
}
//以下為Swift5.9的新語法（只能在Xcode15之後使用）
//if判斷是可以在=之後，視條件成立與否決定如何針對前方的常數或變數設值
/*
 let scoreDecoration = if teamScore > 10 {
 "🎉"
 } else {
 ""
 }
 print("Score:", teamScore, scoreDecoration)
*/

/*
let anotherCharacter: Character = "a"
let message = switch anotherCharacter
{
    case "a":
        "The first letter of the Latin alphabet"
    case "z":
        "The last letter of the Latin alphabet"
    default:
        "Some other character"
}
print(message)
*/

//以下為原語法
let scoreDecoration:String
if teamScore > 10
{
    scoreDecoration = "🎉"  //ctrl-cmd-空白
}
else
{
    scoreDecoration = ""
}
print("Score:", teamScore, scoreDecoration)

//---------選擇性型別與選擇值（optional type vs. optional value）---------
/*
可以使用if和let與可能缺少的值協同運作。這些值表示為選擇值（optional）。
選擇值（optional value）可能包含一個值，
或為nil值（空值），以指示其值的缺少。
在值型別之後帶一個問號（？），將該值標記為選擇值。
不是選擇性型別不得設定為空值(nil)。
*/
//型別推測機制無法推測出選擇性型別，選擇性型別必須明確宣告
var optionalString: String? = "Hello"   //宣告String型別的包裝盒
//print(optionalString)連同包裝一起列印
//error:Expression implicitly coerced from 'String?'
print(optionalString!)  //以美工刀(!)拆掉包裝之後才列印(unwrap)
//把包裝盒清空
optionalString = nil

//注意：當包裝盒為空時，拆開包裝會觸發執行階段錯誤
//print(optionalString!)
//Fatal error: Unexpectedly found nil while unwrapping an Optional value

print(optionalString == nil)
// Prints "false"

//有值才拆包，否則有當機危險
//<方法一>檢查型別的包裝盒是否有內容物
//當不是空的包裝盒時
if optionalString != nil
{
    //才進行強制拆封(force-unwrap)
    print(optionalString!)
}
else    //當空的包裝盒時
{
    print("optionalString為nil")
}

//-------------選擇性綁定（Optional Binding）-------------
//<方法二>以選擇性綁定自動拆封
var optionalName: String? = "John Appleseed"
var greeting1 = "Hello!"
optionalName = nil  //【練習4】
//if let 語法一旦榜定成功會拿到自動拆封的值
if let name = optionalName      //綁定成功時，name會自動拆封
{
    greeting1 = "Hello, \(name)"
}
else                //【練習4】
{
    greeting1 = "Hello"
}

//【練習4】將optionalName設為nil。你會收到了什麼問候？如果optionalName為nil，新增一個else段，該段設定不同的問候語。

//-------------空值合併運算符號（Nil-Coalescing Operator）-------------
//<方法三>以??運算符號來自動拆封，或提供nil時的預設值
//簡化語法～a ?? b （可視為方法一不為空時 的簡易做法）
//完整語法～a != nil ? a! : b
// != (意思是不等於） == (意思是 等於 ）
var nickname: String? //= nil       //原範例為let
let fullName: String = "John Appleseed"
let informalGreeting = "Hi \(nickname ?? fullName)"
nickname = "老鼠"
let informalGreeting1 = "Hi \(nickname ?? fullName)"
//以下為<方法一>的改寫版
if nickname != nil     //  包裝盒不為空值時
{
    let informalGreeting = "Hi \(nickname!)"
}
else
{
    let informalGreeting = "Hi \(fullName)"
}

//<方法四>同<方法二>，但綁定的常數以跟選擇值的常數或變數相同的名稱命名，因此可以省略=後方的語法
//（當綁定的常數名稱 與包裝盒名稱相同 可用此語法）
//以下為Swift5.7之後的新語法
if let nickname //= nickname
{
    print("Hey, \(nickname)")
}

//switch檢測架構支援任何型別的資料（不僅限於整數）和各種的比較運算（不只是相等測試）。
let vegetable = "red pepper"
switch vegetable
{
    //每一個case的最後一行，不需要break指令（因為會自動break）
    case "celery":
        print("Add some raisins and make ants on a log.")
    case "cucumber", "watercress":
        print("That would make a good tea sandwich.")
    case let x where x.hasSuffix("pepper"):
        print("Is it a spicy \(x)?")
    default:        //注意：當前方的case無法完全攔截時，default段不可省略！
        print("Everything tastes good in soup.")
}
//error:Switch must be exhaustive(詳盡)

//<補充>以Switch攔截特定範圍（Range）
let approximateCount = 62
let countedThings = "moons orbiting Saturn"
let naturalCount: String
switch approximateCount
{
    case 0:
        naturalCount = "no"
    case 1..<5:     //1~4
        naturalCount = "a few"
    case 5..<12:    //5~11
        naturalCount = "several"
    case 12..<100:  //12~99
        naturalCount = "dozens of"
    case 100..<1000://100~999
        naturalCount = "hundreds of"
    default:
        naturalCount = "many"
}
print("There are \(naturalCount) \(countedThings).")

//以switch來進行比較運算
var aDouble = Double.pi
aDouble = -3.99
switch aDouble
{
    case Double.pi:
        print("圓周率：\(aDouble)")
    case let dbl where dbl >= 0:
        print("浮點數為正數：\(dbl)")
    case let dbl where dbl < 0:
        print("浮點數為負數：\(dbl)")
    default:  //  注意:此段依照現狀的條件，沒有被執行到的機會
        break //  可增加 break 直接離開
}

//【練習5】嘗試刪除預設的case。你看到什麼錯誤訊息？
//error: Switch must be exhaustive

//以下為switch的if-else版本
if vegetable == "celery"
{
    print("Add some raisins and make ants on a log.")
}
else if vegetable == "cucumber" || vegetable == "watercress"
{
    print("That would make a good tea sandwich.")
}
else if vegetable.hasSuffix("pepper")
{
    print("Is it a spicy \(vegetable)?")
}
else
{
    print("Everything tastes good in soup.")
}

//for-in迴圈也可以列出字典，可以同時取得字典key和value
//----------- for in迴圈 可列出字典 同時取得key ,value ,為無序順序

let interestingNumbers = [                  //字典型別～[Sting:[Int]]
    "Prime": [2, 3, 5, 7, 11, 13],          //Prime 質數陣列
    "Fibonacci": [1, 1, 2, 3, 5, 8],        //Fibonacci 費式數列
    "Square": [1, 4, 9, 16, 25],            //Square 平方數列
]
//記錄所有數列中的最大值
var largest = 0
//外迴圈列出字典
for (_, numbers) in interestingNumbers      //key值不用可下_ 略過不用
{
    //內迴圈列出陣列
    for number in numbers
    {
        if number > largest
        {
            largest = number
        }
    }
}
print(largest)

//【練習6】用常數名稱來替換上面外迴圈的_，並追蹤最大數出現在哪一種數列。
//先歸零最大數
largest = 0
//記錄最大值所屬的種類（字典的Key）
var largetKind = ""
//外迴圈列出字典
//key值不用可下_ 略過不用
for (kind, numbers) in interestingNumbers   //型別(String, [Int])為Tuple型別（元組）
{
    //內迴圈列出陣列
    for number in numbers
    {
        if number > largest
        {
            //替換最大值
            largest = number
            //替換最大種類
            largetKind = kind
        }
    }
}
print("最大數：\(largest)出現在\(largetKind)數列")

//<補充>以for-in迴圈同時列出陣列的索引值和元素
for (index,score) in individualScores.enumerated()   //[(0,75), (1,43), (2,103), (3,87), (4,12)]
{
    //if條件式必須是Boolean判斷式（true/false）
    if score > 50
    {
        teamScore += 3
        //teamScore = teamScore + 3
    }
    else
    {
        teamScore += 1
    }
    print("index:\(index),score:\(score)")
}
print(teamScore)

//使用while重複執行程式區塊，直到條件發生變化。 迴圈的條件可以在末尾，確保迴圈至少執行一次。
var n = 2
while n < 100           //while迴圈會先測試條件，才決定是否執行
{
    n *= 2  //n = n*2
}
print(n)
// Prints "128"

//  後檢測條件的 repeat-while 迴圈 (就是傳統程式語言的 do-while)
//repeat-while迴圈(do-while迴圈)會先執行一次，再測試條件決定是否執行下一次
var m = 2
repeat
{
    m *= 2
} while m < 100
print(m)

//【練習7】將條件從m < 100更改為m < 0，以檢視當迴圈條件成立時，while和repeat-while的行為有何不同。
m = 2
while m < 0
{
    m *= 2
}

m = 2
repeat
{
    m *= 2
} while m < 0

//for-in迴圈可以使用..<來製作一個不含上標的索引範圍來執行迴圈，或者使用...來製作一個包含上標的索引範圍
let range = 0..<4       //型別：range<Int>

//for - in迴圈透過 ..< 建立一個索引的範圍
            
var total = 0
for i in 0..<4  //[0,1,2,3]
{
    i
    total += i
}
print(total)

//===================函式和閉包（Functions and Closures）===================
/*
使用func關鍵字宣告函式，賦予函式名稱。
函式名稱之後以小括號()定義"參數列表"（parameter list），以逗號區隔每個參數
使用->來標示函式的回傳型別（return type），回傳型別不需要命名（接取回傳值時才需命名）
呼叫函式，在其名稱之後，小括號中傳入對應參數數量的"引數"（argument）。
*/
//------------函式有多個參數------------
//宣告函式（定義函式）
func greet(person: String, day: String) -> String
{
    return "Hello \(person), today is \(day)."
}
//呼叫函式（忽略回傳值）
greet(person: "Bob", day: "Tuesday")
//以命名常數或變數接取函式的回傳值
let greetings = greet(person: "Perkin", day: "Monday")
greetings

//【練習8】刪除day參數。新增一個參數lunch，在問候語中包含今天的特價午餐。
func greet(person: String, lunch: String) -> String
{
    return "\(person)你好：今日特價午餐是\(lunch)。"
}
//呼叫函式
print(greet(person: "Perkin", lunch: "排骨飯"))

//預設情況下，函式使用其"參數名稱"作為其"引數標籤"（argument label）。
//但是你也可在"參數名稱"之前自行定義一個"引數標籤"，或者使用_符號來表明呼叫時不留下"引數標籤"。
func greet(_ person: String, on day: String) -> String
{
    return "Hello \(person), today is \(day)."
}
//呼叫函式
greet("John", on: "Wednesday")

greet("Perkin", on: "星期天")

//-------沒有參數的函式-------
func sayHelloWorld() -> String
{
    return "hello, world"
}
print(sayHelloWorld())

//-------函式沒有回傳值-------
//形式1
func greet1(person: String)
{
    print("Hello, \(person)!")
}
greet1(person: "Dave")
//形式2:回傳Void
func greet2(person: String) -> Void
{
    print("Hello, \(person)!")
}
greet2(person: "Dave")

//形式3:回傳空元組
func greet3(person: String) -> ()
{
    print("Hello, \(person)!")
}
greet3(person: "Dave")

//注意：函式就算沒有回傳值，還是會回傳Void型別，也可以寫成空元組()形式

//-------函式可以有多個回傳值-------
//使用元組（tuple）來製作複合值（compound value）——例如，從函式回傳多個值。 元組的元素可以用名稱或數字來引用。
func calculateStatistics(scores: [Int]) -> (min: Int, max: Int, sum: Int)
{
    var min = scores[0]
    var max = scores[0]
    var sum = 0

    for score in scores
    {
        if score > max
        {
            max = score
        }
        else if score < min
        {
            min = score
        }
        sum += score
        //sum = sum + score
    }

    return (min, max, sum)
}
//呼叫
let statistics = calculateStatistics(scores: [5, 3, 100, 3, 9])
statistics.min
statistics.max
print(statistics.sum)

// Prints "120"
statistics.0
statistics.1
print(statistics.2)

func calculateStatistics1(scores: [Int]) -> (Int, Int, Int) //回傳的元組可以不用命名
{
    var min = scores[0]
    var max = scores[0]
    var sum = 0

    for score in scores
    {
        if score > max
        {
            max = score
        }
        else if score < min
        {
            min = score
        }
        sum += score
        //sum = sum + score
    }

    return (min, max, sum)
}

//呼叫
let statistics1 = calculateStatistics1(scores: [59,33,60])
//函式回傳沒有命名Tuple，只能使用索引值存取其中的元素
statistics1.0
statistics1.1
statistics1.2

/*
函式可以是"巢狀函式"（nested function）。
巢狀函式可以存取宣告在函式外部的變數。
您可以使用巢狀函式來組織較長或較複雜的程式在巢狀函式之中。
*/
func returnFifteen() -> Int
{
    var y = 10
    func add()  //用巢狀函式來組織複雜邏輯
    {
        y += 5
    }
    //呼叫自行定義的"巢狀函式"
    add()
    return y
}
//呼叫
returnFifteen()

//函式是一級型別。這意味著一個函式可以回傳另一個函式。
//函式以參數列表的型別+回傳型別當作『函式型別』
func makeIncrementer() -> ((Int) -> Int)    //回傳函式的外括號可以省略
//func makeIncrementer() -> (Int) -> Int
{
    func addOne(number: Int) -> Int
    {
        return 1 + number
    }
    return addOne
}
//呼叫外部函式（得到的回傳值為一個函式，此處的increment變數為函式）
var increment = makeIncrementer()
//執行increment函式
increment(7)

//一個函式可以用另一個函式來定義其參數，呼叫時"接受函式的參數"需傳入"預先撰寫的實作"來當作『引數』
func hasAnyMatches(list: [Int], condition: (Int) -> Bool) -> Bool
{
    for item in list
    {
        if condition(item)
        {
            return true
        }
    }
    return false
}
//<方法一>以命名函式傳入自定實作
//預先定義準備傳入參數二的運作邏輯
func lessThanTen(number: Int) -> Bool
{
    return number < 10  //定義小於10的判斷邏輯
}
//準備好用於參數一的陣列
var numbers = [20, 19, 7, 12]
//呼叫函式
hasAnyMatches(list: numbers, condition: lessThanTen)
//函式實際上是閉包(可以稍後呼叫的程式區塊)的特殊情況。閉包中的程式可以存取"建立閉包的範圍中"可用的變數和函式等內容，即使閉包在執行時處於不同的範圍。

//<方法二>以匿名函式傳入自定實作(匿名函式就是閉包closure)
hasAnyMatches(list: [50,30,99,60], condition: {
    (number: Int) -> Bool   //參數列表移置到實作的{}之中
    in                      //in關鍵字區隔參數列表和實作
    return number > 100
})

//<方法三>以"尾隨閉包"(trailing closure)的方式傳入自定實作
hasAnyMatches(list: numbers) {
    number //-> Bool
    in
    return number > 20  //閉包的實作中，如果只有一行回傳值，可以省略return關鍵字
}

//------------陣列的對應處理方法（map方法）------------
//[20, 19, 7, 12]
numbers.map {
    number
    in
    let result = 3 * number
    return result
}

numbers.map({
    (number: Int) -> String
    in
    let result = "\(3 * number)"
    return result
})

//猜測map方法的處理邏輯
func myMapping(list:[Int],map:(Int)->Int)->[Int]
{
    var result = [Int]()
    for item in list
    {
        result.append(map(item))
    }
    return result
}

let newArray =
myMapping(list: numbers) {
    number
    in
    return 3*number
}

newArray

//【練習9】重寫閉包，讓所有奇數回傳零（偶數保持不變）。
//[20, 0, 0, 12]
//除法取商數/，除法取餘數%
numbers.map {
    number
    in
    if number % 2 != 0  //被2除不盡者為奇數
    {
        return 0
    }
    return number
}

//以下為簡化寫法
//<簡化一>如果閉包只有一行程式，可以省略return關鍵字
let mappedNumbers = numbers.map({ number in 3 * number })
print(mappedNumbers)

//<簡化二>以$數字來指定閉包中的參數，直接賦予實作
numbers.map {
    $0*3
}
//------------陣列的排序方法（sort方法）------------
//[20, 19, 7, 12]
//排序到新陣列（只能由小到大排列）原陣列不動！
var sortedArray = numbers.sorted()

//陣列原地排序（只能由小到大排列）
numbers.sort()

//以自訂排序邏輯由大到小排序到新陣列（原陣列不動！）
sortedArray = numbers.sorted {
    num1, num2
    in
    return num1 > num2
}

//以自訂排序邏輯由大到小原地排序
numbers.sort {
    num1, num2
    in
    return num1 > num2
}
numbers
//以下為簡化寫法
let sortedNumbers = numbers.sorted { $0 > $1 }
print(sortedNumbers)

//陣列元素為集合型別（自訂型別）時，只能執行自定排序方法
var dicArray = [["abc":123,"def":456],["abc":789,"jkl":777,"qwe":888],["abc":333,"jkl":777,"qwe":888]]
//以上假設陣列中的每一本字典都有abc的key
let newDicArray =
dicArray.sorted {
    dic1, dic2 in
    dic1["abc"]! < dic2["abc"]!
}

//===============類別和物件（Classes and Objects）===============
//===============類別和實體（Classes and Instances）===============
/*
 注意：
 類別的實體（instance）傳統上被稱為物件（object）。
 然而，Swift的結構（structure）和類別（class）在功能上比其他語言更接近，所以使用"實體"（instance）來稱呼類別、結構或列舉所產生的物件。
*/
/*
使用class關鍵字來宣告類別。
類別的實作中，屬性（property）宣告與"常數"或"變數"宣告的方式相同。
方法（method）的宣告和"函式"的宣告方式相同。
*/
//宣告類別
class Shape     //沒有繼承的類別稱為基礎類別（bass class）
{
    //當所有屬性都有初始值時，類別會自動得到一個不帶參數的初始化方法（initializer）
    //邊數"屬性"（可讀可寫的儲存屬性）
    //  增加一個常數屬性(唯讀)
    var numberOfSides = 0
    //【練習10】新增一個常數屬性（唯讀儲存屬性 get-only）
    let dimension = "3D"
    //列印"方法"
    func simpleDescription() -> String
    {
        return "A shape with \(numberOfSides) sides."
    }
    //【練習10】新增另一個接受引數的方法
    func shapeWithHeight(height:Int) -> String
    {
        return "這是\(dimension)形狀，高度\(height)公分"
    }
}

//【練習10】使用let新增一個常數屬性，並新增另一個接受引數的方法。

//在類別名稱後面加上小括號來建立類別的實體（instance of a class）。使用點語法來存取實體的屬性和方法。
//以變數來記錄配置的記憶體空間
//初始化類別實體
var shape = Shape()
//點語法存取實體的屬性(使用 . (點語法)來存取實體的屬性)
shape.numberOfSides
//  讀取屬性值
shape.numberOfSides = 7
//  儲存屬性值
shape.numberOfSides
shape.dimension
//點語法呼叫實體的方法
var shapeDescription = shape.simpleDescription()
shape.shapeWithHeight(height: 30)

//這個版本的Shape類別某些屬性缺少初始值，因此在宣告類別時，必須提供初始化方法，來為缺值的屬性補初始值。在建立類別實體時，需呼叫初始化方法（initializer）。 使用init可以建立一個初始化方法。
/*
 類別的實體(instance)在傳統上被稱為物件（object）。
 然而，Swift的結構體 (structure) 和類別 (class)在功能上比其他語言更接近。
 所以使用實體 (instance) 來描述類別或結構的物件。
 */
class NamedShape
{
    //當有任何一個屬性沒有初始值時，類別不會自動得到一個不帶參數的初始化方法（initializer）
    //error:Class 'NamedShape' has no initializers
    var numberOfSides: Int = 0
    var name: String
    //  以 init 關鍵字來定義 "初始化方法" (initializer)
    //  此為指定『初始化方法』 (designated initializer)
    //自定"指定"初始化方法，為缺值的屬性補值（此為指定初始化方法 ps.init之前不帶修飾語）
    init(name: String)
    {
        //當初始化方法的參數名稱與屬性名稱相同時，屬性名稱需加上self關鍵字（如果名稱不一致可省略self）
        self.name = name
    }
    //自定"便利"初始化方法，自己幫缺值的屬性設定預設值（便利初始化方法不能自己設屬性值，只能呼叫自己的"指定"初始化方法）
    convenience init()
    {
//        name = "ABC"
        self.init(name: "ABC")
    }
    convenience init(name1: String)
    {
//        name = "ABC"
        //  只能呼叫自己的初始化方法
        self.init(name: "test")
    }
    //定義反初始化方法（deinitialer），其中的實作，會在類別實體被釋放（deallocate）以前"自動"被執行
    deinit
    {
        //執行清理作業
        print("\(name)被釋放")
    }
    
    func simpleDescription() -> String
    {
       return "A shape with \(numberOfSides) sides."
    }
}
//產生類別實體
//執行類別的初始化方法
var aShape:NamedShape? = NamedShape(name: "Test")

print(aShape!.numberOfSides)
aShape!.name

//---------------選擇性串連呼叫（optional chaining）---------------
//選擇性串連呼叫（optional chaining），在任一環節發生nil時，串連即中止，什麼事都不會發生，接取時會得到nil。
//串連後如果取得其值，即使原來不是選擇值時，仍然會得到該型別的選擇值。
print(aShape?.numberOfSides)
//清除配置記憶體空間
aShape = nil
let sides = aShape?.numberOfSides

let description = aShape?.simpleDescription()

//配合選擇性綁定（optional binding），來測試選擇性串連的值，得到的值會自動拆封！
if let description = aShape?.simpleDescription()
{
    print(description)
}
else
{
    print("aShap為nil")
}


//   如果需要在類別實體被 "釋放" (deallocated) 時，執行一些清理作業，可以使用 "deinit" 關鍵字定義『反初始化方法』(deinitializer)


//----------------類別的繼承（inheritance）----------------
//宣告子類別（subclass）時，需在類別名稱之後用冒號分隔，來指定其父類別（superclass）。一個類別不一定要繼承任何標準的根類別，來成為一個子類別，因此您可以依據需要來繼承或不繼承自任何父類別。（objective-c objc的類別，必須至少繼承自NSObject類別）
//覆寫父類別實作的方法，需使用override關鍵字
// Square 類別繼承來自 NamedShape (Square 為子類別，NamedShape 為父類別)
class Square: NamedShape    //類別只會繼承自單一的父類別
{
    //單邊長度屬性
    var sideLength: Double = 0
    /*
    以下兩個屬性繼承自父類別
    var numberOfSides: Int = 0
    var name: String
    */
    /*
    初始化方法有兩種：指定初始化方法和便利初始化方法
    1.指定初始化方法總是向上代理<delegate up>（呼叫父類別的初始化方法）。
    2.便利初始化方法總是橫向代理<delegate cross>（只能呼叫自己類別的指定初始化方法，或其他自己類別便利初始化方法）。
    */
    init(sideLength: Double, name: String)
    {
        //初始化第一階段：為所有屬性準備初值（包含父類別的屬性）
        //Step1.先幫自己類別的屬性準備初值
        self.sideLength = sideLength
        //Step2.呼叫父類別的初始化方法，為父類別的屬性準備初值
        super.init(name: name)
        //初始化第二階段
        //Step3.進一步為有預設值的屬性改值
        numberOfSides = 4
    }
    
    convenience init()
    {
        self.init(sideLength: 5.7, name: "tt")
        //super.init(name: name)
        //error:Convenience initializer for 'Square' must delegate (with 'self.init') rather than chaining to a superclass initializer (with 'super.init')
    }

    //計算正方形面積的方法
    func area() -> Double
    {
        return sideLength * sideLength
    }
    //覆寫父類的方法
    override func simpleDescription() -> String
    {
        return "A square with sides of length \(sideLength)."
    }
}
//測試
let test = Square(sideLength: 5.2, name: "my test square")
test.area()
test.simpleDescription()

//【練習11】宣告Circle類別繼承自NameShape類別，為Circle類別增加半徑（radius）屬性，並設計一個初始化方法帶兩個參數，一個半徑，一個形狀的名稱。撰寫area方法計算圓面積。覆寫simpleDescription方法，直接印出形狀的名稱、半徑和圓面積。
class Circle:NamedShape
{
    var radius:Double
    /*
    以下兩個屬性繼承自父類別
    var numberOfSides: Int = 0
    var name: String
    */
    init(radius:Double,name: String)
    {
        //初始化第一階段：為所有屬性準備初值（包含父類別的屬性）
        //Step1.先幫自己類別的屬性準備初值
        self.radius = radius
        //Step2.呼叫父類別的初始化方法，為父類別的屬性準備初值
        super.init(name: name)
        //初始化第二階段
        //Step3.進一步為有預設值的屬性改值
        numberOfSides = 1
    }
    //計算園面積
    func area() -> Double
    {
        return Double.pi * radius * radius
    }
    
    override func simpleDescription() -> String
    {
        return "圓形：\(name)，半徑：\(radius)，圓面積：\(String(format: "%.2f", area()))"
    }
}
//測試
let circle = Circle(radius: 6.88, name: "大餅")
circle.radius
circle.simpleDescription()

//-------------儲存屬性VS.計算屬性（Stored Property VS. Computed Property）-------------
class EquilateralTriangle: NamedShape
{
    //定義儲存屬性，紀錄單邊長度
    var sideLength: Double = 0.0
    /*
    以下兩個儲存屬性繼承自父類別
    var numberOfSides: Int = 0
    var name: String
    */

    //初始化方法必須為所有儲存屬性設定初值（不管計算屬性）
    init(sideLength: Double, name: String)
    {
        self.sideLength = sideLength
        super.init(name: name)
        numberOfSides = 3
    }

    //定義可讀可寫的"計算屬性"，計算三角形的總邊長
    var perimeter: Double
    {
        //取值段
        get
        {
             return 3.0 * sideLength
        }
        //設值段
        set
        {
//            self.perimeter = newValue //recursion遞迴
            //注意：計算屬性無法存值，只能存放在其他的儲存屬性
            sideLength = newValue / 3.0
        }
    }
    
    //<補充>以唯讀計算屬性來計算三角形面積
    //海龍公式：s=(a+b+c)/2  √s (s-a)(s-b)(s-c) 開根號：sqrt()
    var area:Double
    {
//        get
//        {
            let s = self.perimeter / 2
            return sqrt(s*(s-self.sideLength)*(s-self.sideLength)*(s-self.sideLength))
//        }
    }
    
    override func simpleDescription() -> String
    {
        return "An equilateral triangle with sides of length \(sideLength)."
    }
}
//測試
var triangle = EquilateralTriangle(sideLength: 3.1, name: "a triangle")
print(triangle.perimeter)

triangle.perimeter = 9.9
print(triangle.sideLength)

triangle.area

//---------------------<補充>計算屬性的覆寫---------------------
class Triangle:EquilateralTriangle
{
    /*
    var sideLength: Double = 0.0
    */
    //Error:Cannot override mutable property with read-only property 'perimeter'
    //可讀可寫的計算屬性不能覆寫成唯讀計算屬性
//    override var perimeter: Double
//    {
//        return 3.0 * sideLength
//    }
    //"唯讀"計算屬性可以覆寫成"可讀可寫"的計算屬性
    override var perimeter: Double
    {
        //取值段
        get
        {
             return 3.0 * sideLength
        }
        //設值段
        set(aValue)
        {
            //注意：計算屬性無法存值，只能存放在其他的儲存屬性
            sideLength = aValue / 3.0
        }
    }
    
    override var area: Double
    {
        get
        {
            let s = self.perimeter / 2
            return sqrt(s*(s-self.sideLength)*(s-self.sideLength)*(s-self.sideLength))
        }
        set
        {
            print("三角形面積無法自行設定")
        }
    }
    //提供計算屬性存值的中介"儲存"屬性(使用private關鍵字來定義"私有變數")
    private var tempProperty = 0
    var testComputedProperty:Int
    {
        get
        {
            print("testComputedProperty計算屬性取值")
            return tempProperty
        }
        set
        {
            tempProperty = newValue
        }
    }
    
}

//測試
var triangle1 = Triangle(sideLength: 5, name: "三角形")
triangle1.area
triangle1.area = 0

triangle1.testComputedProperty
triangle1.testComputedProperty = 3
triangle1.testComputedProperty

//---------------------儲存屬性的觸發機制（willSet和didSet）----------------------------
//儲存屬性可以在設定新值之前和之後執行一段程式，請使用willSet和didSet定義。
//注意：以上儲存屬性的觸發機制，只會在"初始化方法之後"觸發。
class TriangleAndSquare
{
    //三角形實體的儲存屬性
    var triangle: EquilateralTriangle
    {
        //即將存值時觸發
        willSet
        {
            //newValue為EquilateralTriangle的類別實體(instance)
            square.sideLength = newValue.sideLength
            //讓三角形的邊長與正方形一致
        }
        //已經存值時觸發
        didSet
        {
            
        }
        //willSet和didSet可以擇一使用或同時使用
    }
    //正方形實體的儲存屬性
    var square: Square
    {
        //即將存值時觸法
        willSet
        {
            //newValue為Square的類別實體(instance)
            triangle.sideLength = newValue.sideLength
            //讓正方形的邊長與一致三角形
        }
    }
    init(size: Double, name: String)
    {
        //注意：初始化方法不會觸發儲存屬性的willSet和didSet
        square = Square(sideLength: size, name: name)
        triangle = EquilateralTriangle(sideLength: size, name: name)
    }
}
//測試
var triangleAndSquare = TriangleAndSquare(size: 10, name: "another test shape")
print(triangleAndSquare.square.sideLength)
triangleAndSquare.square.area()
triangleAndSquare.triangle
// Prints "10.0"
print(triangleAndSquare.triangle.sideLength)
triangleAndSquare.triangle.area

// Prints "10.0"
//在TriangleAndSquare的初始化方法之後更改屬性值，會觸發儲存屬性的觸發機制（willSet和didSet）
triangleAndSquare.square = Square(sideLength: 50, name: "larger square")
triangleAndSquare.square.sideLength
print(triangleAndSquare.triangle.sideLength)

//測試類別的選擇值
let optionalSquare: Square? = Square(sideLength: 2.5, name: "optional square")
//注意：整個選擇性串連的表達式會回傳為選擇值
let sideLength = optionalSquare?.sideLength

//=======================列舉和結構（enumeration and structure）=======================
//---------------------------------------列舉----------------------------------------
//使用enum來建立列舉。 像類和所有其他命名型別一樣，列舉可以有與它們關聯的方法。
Int.min
Int.max
//定義撲克牌牌數列舉
enum Rank:Int,CaseIterable  //列舉帶Int的原始值（raw value）時，會自動得到一個rawValue屬性，且會自動得到一個帶rawValue參數的初始化方法
    //【練習15】加入CaseIterable
{
    case ace = 1   //  改變起算位置，從 1 開始               //王牌
    case two, three, four, five, six, seven, eight, nine, ten   //2-10號牌
    case jack, queen, king                                      //11-13號牌
    //列舉可以定義方法
    func simpleDescription() -> String
    {
        switch self
        {
            //攔截王牌
            //當列舉型別已知時，Rank 可以省略
            case .ace:
                return "ace"
            //攔截騎士牌
            case .jack:
                return "jack"
            //攔截皇后牌
            case .queen:
                return "queen"
            //攔截國王牌
            case .king:
                return "king"
            //攔截數字牌
            //  2 ~ 10 回傳這邊
            default:
                return String(self.rawValue)
                //return "\(self.rawValue)"
        }
    }
}
//********************取得列舉實體********************
//<方法一>以列舉型別使用點語法來取得列舉實體
let ace = Rank.ace
let aceRawValue = ace.rawValue
ace.simpleDescription()

var aRank:Rank? = Rank.eight
aRank?.rawValue
aRank?.simpleDescription()
//  使用 rawValue 屬性，來存取列舉實體的原始值
//print(aRank?.rawValue)

//<方法二>以列舉的初始化方法，帶入原始值來製作列舉實體
//  當 rawValue 的原始值不合法時 (不是介於 1 ~ 13的區間)，會觸發執行階段錯誤的可能
aRank = Rank(rawValue: 13)
aRank?.simpleDescription()

if let aRank = Rank(rawValue: 13)
{
    print(aRank.simpleDescription())
}

if let aRank = Rank(rawValue: 15)
{
    print(aRank.simpleDescription())
}
else
{
    print("無法取得列舉實體")
}

//【練習12】撰寫一個函式，藉由比較兩個Rank的原始值來比較出它們的大小。
func compare(rank1:Rank,rank2:Rank) -> String
{
    if rank1.rawValue < rank2.rawValue
    {
        return "rank1比rank2小"
    }
    else if rank1.rawValue > rank2.rawValue
    {
        return "rank1比rank2大"
    }
    else
    {
        return "rank1和rank2相等"
    }
}
//呼叫函式
compare(rank1: .five, rank2: .queen)

compare(rank1: aRank!, rank2: ace)

compare(rank1: Rank(rawValue: 13)!, rank2: aRank!)

//以選擇性綁定語法來測試列舉的初始化方法
if let convertedRank = Rank(rawValue: 3)
{
    let threeDescription = convertedRank.simpleDescription()
}

//預設情況下，Swift從零開始分配原始值，每次增加一個，但您可以透過明確指定值來更改此行為。 在上面的範例中，Ace被明確指定為1的原始值，其餘的原始值按順序分配。您還可以使用String或Double作為列舉的原始值。 可以使用rawValue屬性存取列舉的原始值。

//--------------<補充>列舉型別"原始值"的不同形式--------------
//不帶原始值的列舉
enum CompassPoint1
{
    case north
    case south
    case east
    case west
}

var compassPoint1 = CompassPoint1.south

//帶原始值Int的列舉
enum CompassPoint2:Int
{
    case north
    case south
    case east
    case west
}

var compassPoint2 = CompassPoint2.south
compassPoint2.rawValue
compassPoint2 = CompassPoint2(rawValue: 3)!

//帶原始值String的列舉，預設以case轉為字串當作原始值
enum CompassPoint3:String
{
    case north
    case south
    case east = "E"
    case west = "W"
}

var compassPoint3:CompassPoint3? = CompassPoint3.south
compassPoint3?.rawValue
compassPoint3 = CompassPoint3(rawValue: "north")
compassPoint3?.rawValue

compassPoint3 = CompassPoint3(rawValue: "E")
compassPoint3?.rawValue

compassPoint3 = CompassPoint3(rawValue: "e")
compassPoint3?.rawValue

compassPoint3 = CompassPoint3(rawValue: "west")
compassPoint3?.rawValue

//列舉可以不帶原始值，也可以帶整數、字串、字元或浮點數的原始值
//帶原始值Double的列舉，預設以0起算的浮點數當作原始值，每個case加一
enum CompassPoint4:Double
{
    case north
    case south
    case east = 2.2
    case west = 3.3
}

var compassPoint4:CompassPoint4? = CompassPoint4.south
compassPoint4?.rawValue

compassPoint4 = CompassPoint4.west
compassPoint4?.rawValue

//帶原始值Character的列舉，沒有預設值，每一個case都必須單獨指定對應的字元
enum CompassPoint5:Character
{
    case north = "n"
    case south = "s"
    case east  = "e"
    case west = "w"
}

var compassPoint5:CompassPoint5? = CompassPoint5.south

//================可失敗初始化方法（Failable Initializers）================
class Animal
{
    //物種屬性
    let species: String
    init?(species: String)
    {
        //當物種為空字串時，不製作類別實體（return nil）
//        if species.isEmpty { return nil }
        if species=="" { return nil }
        self.species = species
    }
    init()
    {
        self.species = "未知物種"
    }
}

var animal = Animal(species: "")
animal?.species
animal = Animal(species: "狗")
animal?.species

var animal1 = Animal()
animal1.species
//定義撲克牌花色列舉（不帶原始值）
enum Suit:CaseIterable      //【練習15】
{
    //黑桃,紅心,方塊,梅花
    case spades, hearts, diamonds, clubs

    func simpleDescription() -> String
    {
        switch self
        {
            case .spades:
                return "♠️"
            case .hearts:
                return "❤️"
            case .diamonds:
                return "♦️"
            case .clubs:
                return "♣️"
        }
    }
    //【練習13】
    func color() -> String
    {
        switch self
        {
            case .spades,.clubs:
                return "黑色"
            case .hearts,.diamonds:
                return "紅色"
        }
    }
}
//測試花色列舉
let hearts = Suit.hearts
let heartsDescription = hearts.simpleDescription()
//【練習13】在Suit列舉中新增一個color()方法，為黑桃和梅花回傳“黑色”，為紅心和方塊回傳“紅色”。
hearts.color()

let spades = Suit.spades
spades.simpleDescription()
spades.color()

//-----------------<補充>列出列舉的所有case（Iterating over Enumeration Cases）-----------------
//對於一些列舉，搜集所有列舉的case是有用的。在列舉名稱後面寫上CaseIterable來啟用此功能。Swift將"所有case的集合"製作為烈舉型別的allCases屬性。
enum Beverage: CaseIterable     //列舉引入CaseIterable協定（protocol）
{
    case coffee, tea, juice
}
//引入CaseIterable協定，列舉會有allCases屬性，其型別為列舉型別的陣列
print(Beverage.allCases)    //此型別為[Beverage]

let numberOfChoices = Beverage.allCases.count
print("\(numberOfChoices) beverages available")

//列出列舉的所有case
for beverage in Beverage.allCases
{
    print(beverage)
}

//----------------列舉的關聯值（Associated Values）----------------
//定義伺服器回應的列舉
enum ServerResponse
{
    case result(String, String) //伺服器回傳的結果
    case failure(String)        //伺服器回傳錯誤訊息
    //【練習14】加入第三個case
    case tide(String,String)
    //<補充練習>列印列舉實體的關聯值
    func simpleDescription() -> String
    {
        switch self
        {
            case let .result(sunrise, sunset):
        //    case .result(let sunrise, let sunset):
                return "Sunrise is at \(sunrise) and sunset is at \(sunset)."
            case let .failure(message):
        //    case .failure(let message):
                return "Failure...  \(message)"
            case let .tide(rising, ebb):
                return "漲潮：\(rising)，退潮：\(ebb)"
        }
    }
}

//測試列舉
let success = ServerResponse.result("6:00 am", "8:09 pm")   //伺服器回應日出和日落時間
let failure = ServerResponse.failure("Out of cheese.")      //伺服器回傳錯誤訊息

////讀取列舉實體的關聯值
//switch success
//{
//    case let .result(sunrise, sunset):
////    case .result(let sunrise, let sunset):
//        print("Sunrise is at \(sunrise) and sunset is at \(sunset).")
//    case let .failure(message):
////    case .failure(let message):
//        print("Failure...  \(message)")
//}
//
//switch failure
//{
//    case let .result(sunrise, sunset):
////    case .result(let sunrise, let sunset):
//        print("Sunrise is at \(sunrise) and sunset is at \(sunset).")
//    case let .failure(message):
////    case .failure(let message):
//        print("Failure...  \(message)")
//}

//呼叫列舉的方法取得關聯值
success.simpleDescription()
failure.simpleDescription()

//【練習14】在ServerResponse列舉中加入第三個case（tide），有兩個關聯值rising（漲潮），ebb（退潮）
let tide = ServerResponse.tide("7:30am", "7:00pm")
tide.simpleDescription()

//---------------------------------------結構----------------------------------------
/*
使用struct建立結構。結構支援許多與類別相同的行為，包括定義方法和初始化方法。
結構和類別之間最重要的區別之一是：結構在程式中傳遞時總是被複製一份（記憶體中會有兩份），但類別是透過引用（reference）傳遞，記憶體中只有一份。
 以下為C語言的用語：
 call by reference
 call by value
*/
//定義撲克牌結構
struct Card
{
    //以變數(或常數)定義結構成員(member)
    var rank: Rank
    var suit: Suit
    //結構會自動得到一個『逐一成員的初始化方法』（memberwise initializer）
    
    //定義"實體方法"（instance method）：列印撲克牌資訊
    func simpleDescription() -> String
    {
        return "\(suit.simpleDescription()):\(rank.simpleDescription())"
    }
    //定義"型別方法"（type method）：回傳一整副撲克牌
    static func fullDeckOfCard() -> [Card]
    {
        //先準備撲克牌的空陣列
        var cards = [Card]()
        //外迴圈跑所有的撲克牌花色
        for aSuit in Suit.allCases
        {
            //內迴圈跑所有的撲克牌牌數
            for aRank in Rank.allCases
            {
                //準備單張撲克牌
                let card = Card(rank: aRank, suit: aSuit)
                //存放在撲克牌陣列
                cards.append(card)
            }
        }
        //回傳完整的撲克牌陣列
        return cards
    }
}

//測試結構
let threeOfSpades = Card(rank: .three, suit: .spades)
let threeOfSpadesDescription = threeOfSpades.simpleDescription()
Card.fullDeckOfCard()

//【練習15】撰寫一個函式，回傳一整副撲克牌的陣列。
//fullDeckOfCard
func fullDeckOfCard() -> [Card]
{
    //先準備撲克牌的空陣列
    var cards = [Card]()
    //外迴圈跑所有的撲克牌花色
    for aSuit in Suit.allCases
    {
        //內迴圈跑所有的撲克牌牌數
        for aRank in Rank.allCases
        {
            //準備單張撲克牌
            let card = Card(rank: aRank, suit: aSuit)
            //存放在撲克牌陣列
            cards.append(card)
        }
    }
    //回傳完整的撲克牌陣列
    return cards
}

//呼叫撲克牌函式
let myCard = fullDeckOfCard()
for card in myCard
{
    card.simpleDescription()
}

//-----------型別屬性VS實體屬性（Type Property vs. Intance Property）-----------
//-----------型別方法VS實體方法（Type method vs. Intance method）---------------
//結構的型別屬性與實體屬性
struct SomeStructure
{
    //定義結構成員(實體屬性)
    var a:Int = 0
    var b:String = ""
//    init()
//    {
//        a = 0
//        b = ""
//    }
    //結構中定義型別屬性
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int
    {
        return 1
    }
}
//測試存取型別屬性
SomeStructure.storedTypeProperty
SomeStructure.computedTypeProperty

var aStructure = SomeStructure()
//存取結構的實體屬性（即結構成員）
aStructure.a
aStructure.b
//以預設值來製作結構實體
aStructure = SomeStructure(a: 5)
aStructure = SomeStructure(b: "test")
aStructure = SomeStructure()

//列舉的型別屬性與實體屬性
enum SomeEnumeration
{
    case a,b
    //注意：Enums must not contain stored properties（列舉不能定義儲存屬性，只能定義計算屬性）
    //定義列舉實體的計算屬性
    var storedIntanceProperty:Double
    {
        return 3.3
    }
    //定義列舉的型別屬性
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int
    {
        return 6
    }
}
//測試列舉的型別屬性和實體屬性
var aEnumeration = SomeEnumeration.a
aEnumeration.storedIntanceProperty
SomeEnumeration.storedTypeProperty
SomeEnumeration.computedTypeProperty

//定義類別的方法和屬性
class SomeClass
{
    //定義類別實體的儲存屬性
    var a:Int = 0
    //定義類別實體的唯讀計算屬性
    var b:String
    {
        return "test"
    }
    //定義類別的型別屬性（不能被子類別覆寫時使用static關鍵字）
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int
    {
        return 27
    }
    //定義類別的型別屬性（可以被子類別覆寫時使用class關鍵字，此關鍵字僅限類別使用）
    class var overrideableComputedTypeProperty: Int
    {
        return 107
    }
    //定義類別的型別方法
    class func someTypeMethod()
    {
        print("SomeClass的實作")
    }
}

var aClass = SomeClass()
//存取實體屬性
aClass.a
aClass.b
//存取型別的屬性和方法
SomeClass.computedTypeProperty
SomeClass.storedTypeProperty
SomeClass.someTypeMethod()

class ABCClass:SomeClass
{
    private static var temp:Int = 0
    //覆寫父類別的型別屬性
    //繼承過來的class型別計算屬性，如果不允許"繼續"繼承時，可以更換為static
    override static var overrideableComputedTypeProperty: Int
    {
        get
        {
            return temp
        }
        set
        {
            temp = newValue
        }
    }
    //覆寫父類別的型別方法
    override class func someTypeMethod()
    {
        print("ABCClass的實作")
    }
}
//初始化子類別
aClass = ABCClass()
ABCClass.computedTypeProperty

ABCClass.overrideableComputedTypeProperty
ABCClass.overrideableComputedTypeProperty = 999
ABCClass.overrideableComputedTypeProperty
ABCClass.someTypeMethod()

//<補充>Subscript（標註）語法定義可以使用[]存取
struct TimesTable
{
    let multiplier: Int
    subscript(index: Int) -> Int
    {
        return multiplier * index
    }
}
let threeTimesTable = TimesTable(multiplier: 3)
print("six times three is \(threeTimesTable[6])")

//================比較結構和類別================
/*
Swift中的結構和類別有很多共同點：
1.定義儲存屬性和計算屬性
2.定義方法
3.定義標註(subscript)，使用標註語法[]來存取其值
4.定義初始化方法以設定其初始狀態
5.擴展預設實作之外的功能（extension）
6.符合協定，提供某種標準功能（protocol）
 
類別具有結構所不具備的額外功能：
1.繼承使一個類別能夠繼承另一個類別。
2.型別轉換（type casting）使您能夠在執行時檢查（check）和解釋（interpret）類別實體的型別。
3.定義反初始化方法（deinitializer）讓類別的實體能夠釋放它分配的任何資源。
4.引用計數（reference counting）允許對類別實體進行多次引用。
（注意：結構和列舉的實體配置空間永遠只有一次引用）

結構和類別之間最重要的區別之一是：結構和列舉在程式中傳遞時總是被複製一份（記憶體中會有兩份），但類別是透過引用（reference）傳遞，記憶體中只有一份。
*/
//定義解析度結構
struct Resolution
{
    //宣告寬、高成員
    var width = 0
    var height = 0
}
//定義影像模式類別
class VideoMode
{
    //定義實體的"結構"屬性（儲存屬性）
    var resolution = Resolution()   //  預設解析度寬高為 0
    var interlaced = false          //非交錯掃描
    var frameRate = 0.0             //更新頻率
    var name: String?               //影像模式名稱
    deinit
    {
        if let name //= name
        {
            print("\(name)被釋放！")
        }
        else
        {
            print("VideoMode實體被釋放！")
        }
    }
}

//測試結構和類別的實體
let someResolution = Resolution()
let someVideoMode = VideoMode()
print("The width of someResolution is \(someResolution.width)")
print("The width of someVideoMode is \(someVideoMode.resolution.width)")
//  Swift 在變更結構屬性時，可以單一設定結構成員的值
//  Object-C 在變更結構屬性時，只能重設整個結構
someVideoMode.resolution.width = 1280
print("The width of someVideoMode is now \(someVideoMode.resolution.width)")
//  初始化 VGA 解析度結構
let vga = Resolution(width: 640, height: 480)
vga.width

//------------Structures and Enumerations Are Value Types------------
//--------------------結構和列舉是值型別（其行為是複製）--------------------
/*
值型別是指在分配給變數或常數或傳遞給函式時複製其值的型別。
在之前的章節中，您實際上一直在廣泛使用值型別。 事實上，Swift中的所有基礎型別——整數、浮點數、布林、字串、陣列和字典——都是值型別，在幕後都是以結構定義其實作。
所有結構和列舉都是Swift中的值型別。 這意味著，您建立的任何結構和列舉實體——以及它們作為屬性的任何值型別——在程式中傳遞時，總是被複製一份。
*/
//  初始化 HD 解析度結構
let hd = Resolution(width: 1920, height: 1080)
var cinema = hd     //此行為為複製，在記憶體中為兩個獨立的記憶體區塊
//copy hd 的結構，此動作會自動產生新的記憶體空間，並配置給 cinema
cinema.width = 2048
print("cinema is now \(cinema.width) pixels wide")
print("hd is still \(hd.width) pixels wide")

//------------------Classes Are Reference Types-------------------
//--------------------類別是引用型別（其行為是引用）--------------------
/*
跟值型別不同，引用型別在分配給變數或常數時，或傳遞給函式時不會被複製一份，而是對同一類別實體進行記憶體的引用。
*/
var tenEighty:VideoMode? = VideoMode()                 //引用計數為1
tenEighty?.resolution = hd   //拷貝1920x1080
tenEighty?.interlaced = true
tenEighty?.name = "1080i"
tenEighty?.frameRate = 25.0

var alsoTenEighty = tenEighty   //此行為是引用，而非複製！此時引用計數加1，變為2
//變更前
alsoTenEighty?.frameRate
tenEighty?.frameRate
//針對任一常數或變數變動
alsoTenEighty?.frameRate = 30.0
//  因為使用的是同一塊記憶體配置空間，所以 frameRate 會一起變動
//變更後兩個變數或常數一起變動
print("The frameRate property of tenEighty is now \(tenEighty!.frameRate)")
alsoTenEighty?.frameRate

tenEighty = nil         //此時引用計數減1，變為1
alsoTenEighty = nil     //此時引用計數減1，變為0，ARC機制自動釋放此記憶體空間

//===================同步運作（Concurrency）===================
//Swift5.7之後才新增的語法(XCode14之前)
//asynchronous:非同步(可以跟其他程式碼"同時"運作)
//synchronous:同步(不能跟其他程式碼"同時"運作)
//使用async來標記一個非同步執行的函式，此函式一旦被呼叫有機會跟其他程式同步運作。
//以下模擬跟特定伺服器取得UserID
func fetchUserID(from server: String) async -> Int
{
    if server == "primary"
    {
        return 97
    }
    return 501
}

//以await關鍵字來呼叫非同步函式時，"非同步函式"的運作會變更為"同步運作"(不能跟其他程式同時執行)，必須等待函式完全執行完畢，才能繼續執行其他程式
func fetchUsername(from server: String) async -> String
{
    //必須await才能拿到函式最後的回傳值（以同步的方式來呼叫非同函式）
    let userID = await fetchUserID(from: server)
    if userID == 501
    {
        return "John Appleseed"
    }
    return "Guest"
}

//使用async let來呼叫非同步函式，讓它與其他非同步程式"同時"執行。
func connectUser(to server: String) async
{
    //以下兩行為非同步運作，可以同時執行
    async let userID = fetchUserID(from: server)
    async let username = fetchUsername(from: server)
    //此行程式需依靠前面的非同步運作取得userID和username之後才能執行，所以使用await關鍵字確保前方運作已經執行完畢
    let greeting = await "Hello \(username), user ID \(userID)"
    print(greeting)
}

//使用Task從"同步程式"（synchronous code）中呼叫非同步函式，而無需等待它們返回。
Task {
    await connectUser(to: "primary")
}

//================協定和擴展（Protocols and Extensions）================
//--------------------------協定（Protocol）---------------------------
//使用protocol宣告協定，定義工作需求（requirement）
protocol ExampleProtocol
{
    //要求實作一個simpleDescription屬性（至少是唯讀屬性）
    var simpleDescription: String { get }
    //要求實作一個adjust實體方法
    mutating func adjust()
    //注意：此方法前方的mutating關鍵字僅適用值型別，引用型別不適用！
    //【練習16】在ExampleProtocol新增另一個要求
    var aInt:Int { get set }
}

//類別、列舉和結構都可以採納協定
//類別採納協定
class SimpleClass: ExampleProtocol
{
    //以實體儲存屬性實作協定屬性
    var simpleDescription: String = "A very simple class."
    //類別自訂的實體儲存屬性
    var anotherProperty: Int = 69105
    //以實體方法實作協定方法
    func adjust()
    {
        simpleDescription += "  Now 100% adjusted."
    }
    //以可讀可寫的儲存屬性實作
    var aInt = 2    //PS.不能實作為 let aInt = 2
    //以可讀可寫的計算屬性實作
//    var aInt:Int
//    {
//        get
//        {
//            return 1
//        }
//        set
//        {
//
//        }
//    }
}
//測試類別
var a = SimpleClass()
a.simpleDescription
a.adjust()
let aDescription = a.simpleDescription
a.aInt

//結構採納協定
struct SimpleStructure: ExampleProtocol
{
    //以結構成員實作協定屬性
    var simpleDescription: String = "A simple structure"
    //以儲存屬性實作為結構成員
    var aInt: Int = 0
    //注意：以計算屬性實作，此屬性不是結構成員
//    var aInt: Int
//    {
//        get
//        {
//            return 3
//        }
//        set
//        {
//
//        }
//    }

    //以實體方法實作協定方法
    mutating func adjust()
    {
        //因為實作變動了值型別的實體屬性（結構成員），必須加上mutating關鍵字
        simpleDescription += " (adjusted)"
    }
}
//測試結構
var b = SimpleStructure()
b.simpleDescription
b.adjust()
let bDescription = b.simpleDescription

//<補充>列舉採納協定
enum SimpleEnumeration:Int,ExampleProtocol
{
    case one=1,two,three                            //原始值1,2,3
    case oneAdjusted,twoAdjusted,threeAdjusted      //原始值4,5,6
    
    //實作唯讀計算屬性
    var simpleDescription: String
    {
        //回傳對應的【一】、【二】、【三】、【一】+、【二】+、【三】+
        switch self
        {
            case .one:
                return "【一】"
            case .two:
                return "【二】"
            case .three:
                return "【三】"
            case .oneAdjusted:
                return "【一】+"
            case .twoAdjusted:
                return "【二】+"
            case .threeAdjusted:
                return "【三】+"
        }
    }
    
    mutating func adjust()
    {
        switch self
        {
            case .one:
                self = .oneAdjusted
            case .two:
                self = .twoAdjusted
            case .three:
                self = .threeAdjusted
            default:    //調整過後的case維持原值
                break
        }
    }
    //以計算屬性實作（注意：列舉不能使用儲存屬性）
    var aInt: Int
    {
        get
        {
           return 5
        }
        set
        {
            
        }
    }
}
//測試列舉
var c = SimpleEnumeration(rawValue: 3)
c?.simpleDescription
c = SimpleEnumeration.threeAdjusted
c?.simpleDescription
c = SimpleEnumeration.two
c?.simpleDescription
c?.adjust()
c
c?.simpleDescription

//【練習16】在ExampleProtocol新增另一個要求。 您需要對SimpleClass和SimpleStructure和SimpleEnumeration進行哪些更改，以便它們仍然符合協定？

//------------<補充>選擇性的協定要求（Optional Protocol Requirements）------------
@objc protocol CounterDataSource
{
    //選擇性實作的屬性方法要加 @objc optional，且須配合 @objc protocol
    @objc optional func increment(forCount count: Int) -> Int
    @objc optional var fixedIncrement: Int { get }
    var aInt:Int { get set }        //必須實作的屬性
}
//*********************以協定當作型別（Protocols as Types）*********************
//計數類別
class Counter
{
    var count = 0
    //有實作過CounterDataSource協定的"類別實體"或"結構實體"或"列舉實體"才能儲存在此屬性
    var dataSource: CounterDataSource?
    
    func increment()
    {
        //注意：increment後方的?，是標明此方法是選擇性實作
        if let amount = dataSource?.increment?(forCount: count)
        {
            count += amount
        }
        else if let amount = dataSource?.fixedIncrement
        {
            count += amount
        }
    }
}
//以ThreeSource實作CounterDataSource協定
class ThreeSource: NSObject, CounterDataSource
{
    //以常數屬性實作選擇性的協定要求
    let fixedIncrement = 3
    //以儲存屬性實作必要的協定要求
    var aInt = 0
    //自己定義的儲存屬性
    var testInt = 0
}
//初始化計數類別
var counter = Counter()
counter.dataSource = ThreeSource()  //此行為是引用，但是視角是協定視角，只能看到協定相關的屬性方法
//執行型別轉換，將視角轉為原來初始化型別的視角，才能看到實體中完整的屬性方法
(counter.dataSource as! ThreeSource).testInt
for _ in 1...4
{
    counter.increment()
    print(counter.count)
}

//注意：a為SimpleClass的類別實體，且實作過ExampleProtocol協定
let protocolValue: any ExampleProtocol = a          //此行為是引用（注意：冒號後的any可以省略）
print(protocolValue.simpleDescription)

a.anotherProperty
(protocolValue as! SimpleClass).anotherProperty

//--------------------------------擴展（Extension）--------------------------------
/*
使用extension關鍵字為既有型別（exiting type）新增功能，例如增加新"方法"和"計算屬性"。
您可以使用擴展替其他地方宣告的型別，或從library或framework匯入的型別，引入協定或直接增加方法或屬性。
*/
extension Int//: ExampleProtocol
{
//    var aInt: Int
//    {
//        get
//        {
//            return 1
//        }
//        set
//        {
//
//        }
//    }
    //為Int型別增加計算屬性
    var simpleDescription: String
    {
        return "The number \(self)"
    }
    mutating func adjust()
    {
        self += 42
    }
}

print(7.simpleDescription)

//7.adjust()
//error:Cannot use mutating member on immutable value: literals are not mutable

var myInt = 7
myInt.simpleDescription
myInt.adjust()
myInt

//=====================錯誤處理（Error Handling）=====================
//使用任何採納過Error協定的型別來表示錯誤
//定義印表機的錯誤
enum PrinterError: Error    //Error為空協定，沒有任何協定要求，引入此協定的目的，是為了識別哪些錯誤可以拋出
{
    case outOfPaper     //缺紙
    case noToner        //沒有碳粉
    case onFire         //故障
}
//練習18增加
enum OtherError: Error
{
    case unknow         //未知錯誤
}
//只有函式會拋出錯誤，在函式的參數列表和回傳值之間，給定throws關鍵字來描述函式可能會拋出錯誤
func send(job: Int, toPrinter printerName: String) throws -> String
{
    //當運作符合特定狀況時，使用throw關鍵字拋出特定錯誤
    if printerName == "Never Has Toner"
    {
        throw PrinterError.noToner
        //當函式拋出錯誤時，函式會立即返回，而且呼叫此函式的程式段需處理錯誤
    }
    //練習18增加
    else if printerName == "Out Of Paper"
    {
        throw PrinterError.outOfPaper
    }
    //練習18增加
    else if printerName == "On Fire"
    {
        throw PrinterError.onFire
    }
    //練習18增加
    else if printerName.isEmpty
    {
        throw OtherError.unknow
    }
    return "Job sent"
}

//呼叫函式沒有產生錯誤時
try send(job: 33, toPrinter: "Epson")
//呼叫函式產生錯誤時，沒有處理錯誤，會觸發執行階段錯誤
//try send(job: 44, toPrinter: "Never Has Toner")

//捕捉錯誤的<方法一>單段式的錯誤捕捉
do  //在do區段配合try語法呼叫會拋出錯誤的函式
{
    let printerResponse = try send(job: 1040, toPrinter: "Bi Sheng")
    print(printerResponse)
}
catch   //如果函式拋出錯誤，會執行catch段，預設的錯誤常數為error
{
    print(error)
    print(error.localizedDescription)   //列印error的實體唯讀屬性
}

//【練習17】將印表機名稱更改為"Never Has Toner"以便send(job:toPrinter:)函式拋出錯誤。
do
{
    try send(job: 999, toPrinter: "Never Has Toner")
}
catch
{
    print(error)
    print(error.localizedDescription)
}
//捕捉錯誤的<方法二>多段式的錯誤捕捉
do
{
    let printerResponse = try send(job: 1440, toPrinter: "Gutenberg")
    print(printerResponse)
}
catch PrinterError.onFire   //第一段：捕捉印表機故障的錯誤
{
    print("I'll just put this over here, with the rest of the fire.")
}
catch let printerError as PrinterError    //第二段：捕捉印表機的其他錯誤（包含缺紙、沒有碳粉）
{
    print("Printer error: \(printerError).")
}
catch                                     //第三段：捕捉不是PrinterError的錯誤
{
    print(error)
}

//【練習18】新增程式以在do區塊中拋出錯誤。您需要拋出什麼樣的錯誤，以便讓第一個catch區塊捕捉錯誤？還有讓第二和第三區塊可以捕捉錯誤呢？
//讓第一段捕捉到錯誤
do
{
    let printerResponse = try send(job: 1440, toPrinter: "On Fire")
    print(printerResponse)
}
catch PrinterError.onFire   //第一段：捕捉印表機故障的錯誤
{
    print("I'll just put this over here, with the rest of the fire.")
}
catch let printerError as PrinterError    //第二段：捕捉印表機的其他錯誤（包含缺紙、沒有碳粉）
{
    print("Printer error: \(printerError).")
}
catch                                     //第三段：捕捉不是PrinterError的錯誤
{
    print(error)
}

//讓第二段捕捉到錯誤
do
{
    let printerResponse = try send(job: 1440, toPrinter: "Out Of Paper")
    print(printerResponse)
}
catch PrinterError.onFire   //第一段：捕捉印表機故障的錯誤
{
    print("I'll just put this over here, with the rest of the fire.")
}
catch let printerError as PrinterError    //第二段：捕捉印表機的其他錯誤（包含缺紙、沒有碳粉）
{
    print("Printer error: \(printerError).")
}
catch                                     //第三段：捕捉不是PrinterError的錯誤
{
    print(error)
}

//讓第三段捕捉到錯誤
do
{
    let printerResponse = try send(job: 1440, toPrinter: "")
    print(printerResponse)
}
catch PrinterError.onFire   //第一段：捕捉印表機故障的錯誤
{
    print("I'll just put this over here, with the rest of the fire.")
}
catch let printerError as PrinterError    //第二段：捕捉印表機的其他錯誤（包含缺紙、沒有碳粉）
{
    print("Printer error: \(printerError).")
}
catch                                     //第三段：捕捉不是PrinterError的錯誤
{
    print(error)
}

//捕捉錯誤的<方法三>以try?呼叫直接忽略錯誤
//處理錯誤的另一種方法是使用try? 將結果轉換為選擇值。 如果函式拋出錯誤，則丟棄特定錯誤，得到的結果為nil。 如果呼叫成功，且函式有回傳值，其結果會是一個選擇值。
let printerSuccess = try? send(job: 1884, toPrinter: "Mergenthaler")
let printerFailure = try? send(job: 1885, toPrinter: "Never Has Toner")

if let printerFailure = try? send(job: 1885, toPrinter: "Never Has Toner")
{
    print(printerFailure)
}
else
{
    print("函式呼叫失敗")
}
//會拋出錯誤的函式有回傳值時，可以使用選擇性綁定語法測試呼叫是否成功（函式沒有回傳值同樣適用）
if let printerFailure = try? send(job: 1885, toPrinter: "Mergenthaler")
{
    print(printerFailure)
}
else
{
    print("函式呼叫失敗")
}

//此函式假定只接受1以上的引數
func noReturnFunction(positiveInt:UInt) throws
{
    if positiveInt == 0
    {
        throw OtherError.unknow
    }
    print("收到：\(positiveInt)")
}

//會拋出錯誤的函式沒有回傳值時，如果使用"型別推測"的常數或變數來接取，會有以下警告訊息～
//warning:Constant 'positiveInt' inferred to have type '()?', which may be unexpected
let positiveInt: ()? = try? noReturnFunction(positiveInt: 0)

//此行為正常做法，會拋出錯誤的函式，不需使用常數或變數接值
try? noReturnFunction(positiveInt: 0)

//函式沒有回傳值同樣適用選擇性綁定來測試呼叫是否成功
if let positiveInt = try? noReturnFunction(positiveInt: 0)
{
    print("呼叫成功")
}
else
{
    print("呼叫失敗")
}

//--------------函式defer區段--------------
//使用defer撰寫程式區塊，該區塊在函式中所有其他程式之後才會被執行，包含函式正常返回或拋出錯誤之前，defer區段都會被執行。 您可以使用defer將函式一開始的設定和最後的清理作業撰寫在一起，以方便程式撰寫時比對作業。

//冰箱的初始狀態為關閉
var fridgeIsOpen = false
//冰箱的內容
let fridgeContent = ["milk", "eggs", "leftovers"]

//確認冰箱內含物的函式
func fridgeContains(_ food: String) -> Bool
{
    //打開冰箱
    fridgeIsOpen = true
    //函式返回或拋出錯誤之前，一定關上冰箱
    defer
    {
        fridgeIsOpen = false
    }
    let result = fridgeContent.contains(food)
    return result
}

if fridgeContains("banana")
{
    print("冰箱有香蕉")
}
else
{
    print("冰箱沒有香蕉")
}
//冰箱已經在defer區段被關上
print(fridgeIsOpen)

//-------------<補充>回拋函式或方法的錯誤（Rethrowing Functions and Methods）-------------
//定義函式其參數接受一個會拋出錯誤的閉包，但實作中不處理錯誤
func someFunction1(callback: () throws -> Void) rethrows
{
    //注意：此處執行閉包但沒有處理錯誤
    try callback()
}
//呼叫時，傳入參數的實作不含拋出錯誤的程式，不需捕捉錯誤
someFunction1 {
    print("這是不會拋出錯誤的實作")
}
//呼叫時，傳入參數的實作包含拋出錯誤的程式，必需在此捕捉回拋錯誤
try? someFunction1 {
    throw OtherError.unknow
}

//<對比>定義函式接受一個會拋出錯誤的閉包，實作中會捕捉錯誤
func someFunction2(callback: () throws -> Void)
{
    //函式執行閉包時，自己處理錯誤的捕捉
    do {
        try callback()
    }
    catch
    {
        print(error)
    }
}
//呼叫時傳入參數的實作包含拋出錯誤的程式，但因為someFunction2已經捕捉了錯誤，並不會回拋錯誤，所以不需進行錯誤處理
someFunction2 {
    throw OtherError.unknow
}

//==================（泛用型別／泛型）Generics==================
//定義指定型別的函式
func makeArray(repeating item: Int, numberOfTimes: Int) -> [Int]
{
//    var result: [Int] = []
    var result = [Int]()
    for _ in 0..<numberOfTimes
    {
         result.append(item)
    }
    return result
}
//呼叫
makeArray(repeating: 3, numberOfTimes: 5)

func makeArray(repeating item: String, numberOfTimes: Int) -> [String]
{
    var result = [String]()
    for _ in 0..<numberOfTimes
    {
         result.append(item)
    }
    return result
}

makeArray(repeating: "test", numberOfTimes: 5)


//在角括號內自訂泛型的名稱，此為型別的代用名稱（非真實型別），來製作泛型函式或泛用型別。

func makeArray<Item>(repeating item: Item, numberOfTimes: Int) -> [Item]
{
//    var result: [Item] = []
    var result = [Item]()
    for _ in 0..<numberOfTimes
    {
         result.append(item)
    }
    return result
}

makeArray(repeating: "knock", numberOfTimes: 4)

makeArray(repeating: 3.99, numberOfTimes: 5)

//您可以利用泛型製作函式和方法，以及類別、列舉和結構。
//以下範例重新實作了Swift標準函式庫的選擇性型別
// Reimplement the Swift standard library's optional type
enum OptionalValue<Wrapped>
{
    case none
    case some(Wrapped)
}
//測試以"明確型別"替換泛型
var possibleInteger: OptionalValue<Int> = .none
possibleInteger = .some(100)
//以"型別推測機制"指定列舉的關聯值來替換泛型
var pInterger = OptionalValue.some("ABC")
pInterger = .none


enum OptionalValue1<Wrapped,Item>
{
    case none
    case some(Wrapped)
    //型別中定義泛型的實體方法
//    func makeArray<Item>(repeating item: Item, numberOfTimes: Int) -> [Item]
//    {
//    //    var result: [Item] = []
//        var result = [Item]()
//        for _ in 0..<numberOfTimes
//        {
//             result.append(item)
//        }
//        return result
//    }
    
    func makeArray(repeating item: Item, numberOfTimes: Int) -> [Item]
    {
    //    var result: [Item] = []
        var result = [Item]()
        for _ in 0..<numberOfTimes
        {
             result.append(item)
        }
        return result
    }
}
//測試以明確型別替換泛型
var possibleInteger1: OptionalValue1<Int,String> = .none
possibleInteger1 = .some(100)


//以下函式在比對兩個集合（採納過Sequence協定）是否共同元素
//在函式實作之前使用where來指定需求列表——例如，要求型別來實作協定，要求兩個型別相同，或要求類別具有特定的父類別。
                        //函式使用T和U兩種泛型
func anyCommonElements<T: Sequence, U: Sequence>(_ lhs: T, _ rhs: U) -> Bool
    //where條件要求1.T元素的型別必須採納過相等協定 2.T元素的型別必須與U元素的型別一致
    where T.Element: Equatable, T.Element == U.Element
{
    for lhsItem in lhs
    {
        for rhsItem in rhs
        {
            if lhsItem == rhsItem
            {
                return true
            }
        }
    }
   return false
}
//呼叫函式
anyCommonElements([1, 2, 3], [3,5])
anyCommonElements([1, 2, 3], [4,6])

//【練習19】修改anyCommonElements函式，讓函式回傳任何兩個序列共同元素的陣列。
func anyCommonElements1<T: Sequence, U: Sequence>(_ lhs: T, _ rhs: U) -> [T.Element]
    //where條件要求1.T元素的型別必須採納過相等協定 2.T元素的型別必須與U元素的型別一致
    where T.Element: Equatable, T.Element == U.Element
{
    //先準備存放共同元素的陣列
    var commons = [T.Element]()
    for lhsItem in lhs
    {
        for rhsItem in rhs
        {
            if lhsItem == rhsItem
            {
                commons.append(lhsItem)
            }
        }
    }
   return commons
}
//測試
anyCommonElements1(["a","b","c","e","f"], ["b","h","e","j"])

//只用一種泛型來實現以上相同實作
func anyCommonElements2<T: Sequence>(_ lhs: T, _ rhs: T) -> [T.Element]
    //where條件要求T元素的型別必須採納過相等協定
    where T.Element: Equatable
{
    //先準備存放共同元素的陣列
    var commons = [T.Element]()
    for lhsItem in lhs
    {
        for rhsItem in rhs
        {
            if lhsItem == rhsItem
            {
                commons.append(lhsItem)
            }
        }
    }
   return commons
}
//測試
anyCommonElements2(["a","b","c","e","f"], ["b","h","e","j"])

//----------------<補充>相等協定VS比較協定----------------
//Comparable協定引伸自Equatable協定（Comparable協定包含Equatable協定），且已經提供預設實作
struct My3DPoit:Comparable
{
    var x:Int
    var y:Int
    var z:Int
    //唯一必須實作的Comparable協定方法，其他實作會依照此實作自動提供
    static func < (lhs: My3DPoit, rhs: My3DPoit) -> Bool
    {
        return lhs.x < rhs.x && lhs.y < rhs.y && lhs.z < rhs.z
    }
}

let point1 = My3DPoit(x: 3, y: 4, z: 5)
let point2 = My3DPoit(x: 5, y: 4, z: 3)
let point3 = My3DPoit(x: 6, y: 7, z: 8)
let point4 = My3DPoit(x: 3, y: 4, z: 5)

if point1 == point2
{
    print("point1和point2相等")
}
else
{
    print("point1和point2不相等")
}

if point1 == point4
{
    print("point1和point4相等")
}
else
{
    print("point1和point4不相等")
}

if point1 != point4
{
    print("point1和point4不相等")
}
else
{
    print("point1和point4相等")
}

if point1 < point3
{
    print("point1比point3小")
}
else
{
    print("point1不會比point3小")
}

if point1 >= point3
{
    print("point1>=point3")
}
else
{
    print("point1不會>=point3")
}


